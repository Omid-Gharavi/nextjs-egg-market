import HistoryLayout from "@/components/history/HistoryLayout";

export default function Page() {
    return <HistoryLayout placeholder={'از:'} />
}