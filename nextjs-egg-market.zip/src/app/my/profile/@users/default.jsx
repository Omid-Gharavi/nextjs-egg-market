export default function DefaultPhoneslot() {
    return <h1>Default phone slot</h1>
}