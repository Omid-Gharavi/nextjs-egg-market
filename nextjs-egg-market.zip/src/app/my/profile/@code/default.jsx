export default function DefaultCode() {
    return <h1>Default Code Page</h1>
}