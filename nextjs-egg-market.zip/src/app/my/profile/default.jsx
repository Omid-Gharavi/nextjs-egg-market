export default function DefaultProfile() {
    return <h1>Profile Default</h1>
}